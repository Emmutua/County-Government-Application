<h1><strong>Applications</strong></h1>
<table border="1"style="overflow:scroll;background-color:#ADD8E6; ">
		<tr style="background-color:#F0E68C">
			<td>No</td>
			<td>FName</td>
			<td>LName</td>
            <td>IdNO</td>
            <td>Education Level</td>
            <td>School</td> 
            <td>Additional Details</td>  
		</tr>
		<?php
		include("./applications.php");
		?>
		</table>
